def ternary(cond1, result1, result2):
    if cond1:
        return result1
    else:
        return result2
